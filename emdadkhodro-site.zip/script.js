
function sendToWhatsApp(event) {
  event.preventDefault();

  const name = document.getElementById('name').value;
  const phone = document.getElementById('phone').value;
  const location = document.getElementById('location').value;
  const issue = document.getElementById('issue').value;

  const message = `درخواست امداد خودرو:\n\nنام: ${name}\nشماره تماس: ${phone}\nموقعیت: ${location}\nمشکل خودرو: ${issue}`;
  const encodedMessage = encodeURIComponent(message);

  const phoneNumber = "989385464044";
  const url = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;

  window.open(url, '_blank');
}
